Main Page is index.php
Backend.php queries the sql database and displays a table

The other php files are for website functionality.
  Checkout.php is for checking out items from the database
  Return.php is for returning items

Managementpage.php is for administrative actions
  update.php to update information in the database
  insert.php to add new items to database
  etc.
